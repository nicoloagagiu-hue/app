<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_Applications {

    public function init() {
        add_action('init', [$this, 'handle_application_submit']);
        add_filter('the_content', [$this, 'inject_apply_button_into_job'], 20);
    }

    public function inject_apply_button_into_job($content) {

        if ( ! is_singular('job') || ! in_the_loop() || ! is_main_query() ) {
            return $content;
        }

        if ( ! is_user_logged_in() || ! workora_jobs_user_is_student() ) {
            return $content;
        }

        $status = $_GET['applied'] ?? '';

        if ($status === 'success') {
            $content .= '<div class="mt-4 p-3 bg-green-100 text-green-800 rounded-lg">'
                . esc_html__('Application submitted successfully!', WORKORA_JOBS_TEXTDOMAIN)
                . '</div>';
        }
        if ($status === 'fail') {
            $content .= '<div class="mt-4 p-3 bg-red-100 text-red-800 rounded-lg">'
                . esc_html__('Something went wrong. Try again.', WORKORA_JOBS_TEXTDOMAIN)
                . '</div>';
        }
        if ($status === 'already') {
            $content .= '<div class="mt-4 p-3 bg-yellow-100 text-yellow-800 rounded-lg">'
                . esc_html__('You already applied for this job.', WORKORA_JOBS_TEXTDOMAIN)
                . '</div>';
        }

        $job_id = get_the_ID();
        $student_id = get_current_user_id();

        if ( $this->has_applied($student_id, $job_id) ) {
            $btn = '<div class="mt-6 p-3 rounded-lg bg-yellow-50 text-yellow-800">' .
                   esc_html__('You already applied for this job.', WORKORA_JOBS_TEXTDOMAIN) .
                   '</div>';
            return $content . $btn;
        }

        $apply_url = add_query_arg([
            'workora_apply' => 1,
            'job_id' => $job_id,
            WORKORA_NONCE_NAME => wp_create_nonce(WORKORA_NONCE_ACTION),
        ]);

        $btn = '
        <div class="mt-6">
            <a href="'.esc_url($apply_url).'" class="inline-block bg-black text-white px-6 py-3 rounded-lg">
                '.esc_html__('Apply Now', WORKORA_JOBS_TEXTDOMAIN).'
            </a>
        </div>';

        return $content . $btn;
    }

    public function handle_application_submit() {

        if ( ! isset($_GET['workora_apply'], $_GET['job_id'], $_GET[WORKORA_NONCE_NAME]) ) return;
        if ( ! is_user_logged_in() || ! workora_jobs_user_is_student() ) return;

        $nonce = sanitize_text_field($_GET[WORKORA_NONCE_NAME]);
        if ( ! wp_verify_nonce($nonce, WORKORA_NONCE_ACTION) ) {
            wp_die(__('Security check failed.', WORKORA_JOBS_TEXTDOMAIN));
        }

        $job_id = intval($_GET['job_id']);
        if ( $job_id <= 0 || get_post_type($job_id) !== 'job' ) return;

        $student_id = get_current_user_id();

        if ( $this->has_applied($student_id, $job_id) ) {
            wp_safe_redirect( add_query_arg('applied', 'already', get_permalink($job_id)) );
            exit;
        }

        $company_id = (int) get_post_field('post_author', $job_id);

        $application_id = wp_insert_post([
            'post_type'   => 'application',
            'post_status' => 'publish',
            'post_title'  => sprintf(__('Application: Student %d -> Job %d', WORKORA_JOBS_TEXTDOMAIN), $student_id, $job_id),
            'post_author' => $student_id,
        ]);

        if ( $application_id ) {
            update_post_meta($application_id, '_workora_job_id', $job_id);
            update_post_meta($application_id, '_workora_student_id', $student_id);
            update_post_meta($application_id, '_workora_company_id', $company_id);

            wp_safe_redirect( add_query_arg('applied', 'success', get_permalink($job_id)) );
            exit;
        }

        wp_safe_redirect( add_query_arg('applied', 'fail', get_permalink($job_id)) );
        exit;
    }

    public function has_applied($student_id, $job_id) {

        $q = new WP_Query([
            'post_type'      => 'application',
            'posts_per_page' => 1,
            'meta_query'     => [
                [
                    'key'   => '_workora_job_id',
                    'value' => $job_id,
                    'compare' => '='
                ],
                [
                    'key'   => '_workora_student_id',
                    'value' => $student_id,
                    'compare' => '='
                ]
            ]
        ]);

        return $q->have_posts();
    }
}
