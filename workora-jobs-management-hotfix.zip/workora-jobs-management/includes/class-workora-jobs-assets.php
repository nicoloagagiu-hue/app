<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_Assets {

    public function init() {
        add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_tailwind' ] );
    }

    public function enqueue_tailwind() {

        if ( ! is_singular() ) return;

        global $post;
        if ( ! $post ) return;

        $content = $post->post_content;

        $needs_tailwind =
            has_shortcode( $content, 'student_dashboard' ) ||
            has_shortcode( $content, 'company_dashboard' ) ||
            has_shortcode( $content, 'workora_registration' ) ||
            has_shortcode( $content, 'student_public_profile' ) ||
            has_shortcode( $content, 'company_create_job' ) ||
            has_shortcode( $content, 'workora_register' ) ||
            has_shortcode( $content, 'workora_home_jobs' );

        if ( ! $needs_tailwind ) return;

                // Media uploader (immagine profilo)
        if ( has_shortcode( $content, 'student_dashboard' ) ) {
            wp_enqueue_media();
            wp_enqueue_script(
                'workora-student-media',
                WORKORA_JOBS_URL . 'includes/student-media.js',
                ['jquery'],
                WORKORA_JOBS_VERSION,
                true
            );
        }

        wp_enqueue_script(
            'workora-tailwind',
            'https://cdn.tailwindcss.com',
            [],
            null,
            false
        );
    }
}
