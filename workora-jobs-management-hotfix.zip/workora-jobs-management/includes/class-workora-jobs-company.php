<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_Company {

    public function init() {}

    public static function get_unlocked_students( $company_id ) {
        $arr = get_user_meta( $company_id, WORKORA_META_UNLOCKED_STUDENTS, true );
        return is_array($arr) ? $arr : [];
    }

    public static function company_has_unlocked( $company_id, $student_id ) {
        $unlocked = self::get_unlocked_students( $company_id );
        return in_array( intval($student_id), $unlocked, true );
    }
}
