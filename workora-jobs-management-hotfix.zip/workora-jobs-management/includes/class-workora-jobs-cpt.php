<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_CPT {

    public function init() {
        add_action( 'init', [ $this, 'register_cpt' ] );
    }

    public function register_cpt() {

        register_post_type( 'job', [
            'label' => __( 'Jobs', WORKORA_JOBS_TEXTDOMAIN ),
            'public' => true,
            'show_in_rest' => true,
            'supports' => [ 'title', 'editor', 'author' ],
        ] );

        register_post_type( 'application', [
            'label' => __( 'Applications', WORKORA_JOBS_TEXTDOMAIN ),
            'public' => false,
            'show_ui' => true,
            'show_in_rest' => true,
            'supports' => [ 'title', 'author' ],
        ] );
    }
}
