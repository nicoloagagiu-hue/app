<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_Home {

    public function init() {
        add_shortcode('workora_home_jobs', [$this, 'render_home_jobs']);
    }

    public function render_home_jobs($atts = []) {

        $atts = shortcode_atts([
            'per_page' => 12,
        ], $atts);

        $q = new WP_Query([
            'post_type' => 'job',
            'posts_per_page' => intval($atts['per_page']),
            'post_status' => 'publish',
        ]);

        ob_start();
        ?>
        <div class="max-w-6xl mx-auto">
            <div class="flex flex-col md:flex-row md:items-end md:justify-between gap-4 mb-6">
                <div>
                    <h1 class="text-3xl font-bold"><?php echo esc_html__('Job Opportunities', WORKORA_JOBS_TEXTDOMAIN); ?></h1>
                    <p class="text-gray-600 mt-1"><?php echo esc_html__('Browse the latest offers and apply in one click.', WORKORA_JOBS_TEXTDOMAIN); ?></p>
                </div>
                <div class="flex gap-2">
                    <?php if ( ! is_user_logged_in() ): ?>
                        <a href="<?php echo esc_url( site_url('/registrazione/') ); ?>" class="bg-black text-white px-4 py-2 rounded-lg">
                            <?php echo esc_html__('Register', WORKORA_JOBS_TEXTDOMAIN); ?>
                        </a>
                        <a href="<?php echo esc_url( wc_get_page_permalink('myaccount') ); ?>" class="border px-4 py-2 rounded-lg">
                            <?php echo esc_html__('Login', WORKORA_JOBS_TEXTDOMAIN); ?>
                        </a>
                    <?php else: ?>
                        <?php if ( workora_jobs_user_is_company() ): ?>
                            <a href="<?php echo esc_url( site_url('/crea-offerta/') ); ?>" class="bg-black text-white px-4 py-2 rounded-lg">
                                <?php echo esc_html__('Publish a Job', WORKORA_JOBS_TEXTDOMAIN); ?>
                            </a>
                            <a href="<?php echo esc_url( site_url('/dashboard-azienda/') ); ?>" class="border px-4 py-2 rounded-lg">
                                <?php echo esc_html__('Company Dashboard', WORKORA_JOBS_TEXTDOMAIN); ?>
                            </a>
                        <?php else: ?>
                            <a href="<?php echo esc_url( site_url('/dashboard-studente/') ); ?>" class="border px-4 py-2 rounded-lg">
                                <?php echo esc_html__('Student Dashboard', WORKORA_JOBS_TEXTDOMAIN); ?>
                            </a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>

            <div class="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
                <?php if ( $q->have_posts() ): while ( $q->have_posts() ): $q->the_post(); ?>
                    <a href="<?php the_permalink(); ?>" class="block border rounded-2xl p-5 hover:shadow transition">
                        <h2 class="text-lg font-bold"><?php the_title(); ?></h2>
                        <div class="text-sm text-gray-600 mt-2 line-clamp-3">
                            <?php echo esc_html( wp_strip_all_tags( get_the_excerpt() ?: get_the_content() ) ); ?>
                        </div>
                        <div class="mt-4 text-sm font-semibold">
                            <?php echo esc_html__('View details →', WORKORA_JOBS_TEXTDOMAIN); ?>
                        </div>
                    </a>
                <?php endwhile; wp_reset_postdata(); else: ?>
                    <div class="col-span-full p-4 bg-gray-50 rounded-xl text-gray-700">
                        <?php echo esc_html__('No job offers available yet.', WORKORA_JOBS_TEXTDOMAIN); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
