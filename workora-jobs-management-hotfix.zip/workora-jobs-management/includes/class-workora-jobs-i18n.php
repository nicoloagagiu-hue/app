<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_I18n {

    public function init() {
        add_action( 'init', [ $this, 'load_textdomain' ] );
    }

    public function load_textdomain() {
        load_plugin_textdomain(
            WORKORA_JOBS_TEXTDOMAIN,
            false,
            dirname( plugin_basename( __FILE__ ), 2 ) . '/languages/'
        );
    }
}
