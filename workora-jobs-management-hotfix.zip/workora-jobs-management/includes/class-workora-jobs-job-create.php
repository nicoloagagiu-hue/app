<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_Job_Create {

    public function init() {
        add_action('init', [$this, 'handle_job_create']);
    }

    public function handle_job_create() {

        if ( ! isset($_POST['workora_create_job_submit']) ) return;
        if ( ! is_user_logged_in() || ! workora_jobs_user_is_company() ) return;

        if ( ! isset($_POST[WORKORA_NONCE_NAME]) ||
             ! wp_verify_nonce($_POST[WORKORA_NONCE_NAME], WORKORA_NONCE_ACTION) ) {
            wp_die( __( 'Security check failed.', WORKORA_JOBS_TEXTDOMAIN ) );
        }

        $title = sanitize_text_field($_POST['job_title'] ?? '');
        $desc  = sanitize_textarea_field($_POST['job_description'] ?? '');

        if ( empty($title) || empty($desc) ) {
            wp_safe_redirect( add_query_arg('job_created', 'fail', wp_get_referer()) );
            exit;
        }

        $job_id = wp_insert_post([
            'post_type'   => 'job',
            'post_status' => 'publish',
            'post_title'  => $title,
            'post_content'=> $desc,
            'post_author' => get_current_user_id(),
        ]);

        if ( $job_id ) {
            wp_safe_redirect( add_query_arg(['job_created' => 'success', 'job_id' => $job_id], wp_get_referer()) );
            exit;
        }

        wp_safe_redirect( add_query_arg('job_created', 'fail', wp_get_referer()) );
        exit;
    }
}
