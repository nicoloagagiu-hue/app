<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_Job_Manage {

    const META_CLOSED_AT = '_workora_closed_at';
    const CRON_HOOK = 'workora_jobs_cleanup_closed_jobs';

    public function init() {
        add_action('init', [$this, 'handle_close_job']);
        add_action(self::CRON_HOOK, [$this, 'cleanup_closed_jobs']);

        // Schedule cron if not scheduled
        if ( ! wp_next_scheduled(self::CRON_HOOK) ) {
            wp_schedule_event(time() + 3600, 'daily', self::CRON_HOOK);
        }

        // Clear on deactivation
        register_deactivation_hook( WORKORA_JOBS_PATH . 'workora-jobs-management.php', [ $this, 'deactivate' ] );
    }

    public function deactivate() {
        $timestamp = wp_next_scheduled(self::CRON_HOOK);
        if ( $timestamp ) {
            wp_unschedule_event($timestamp, self::CRON_HOOK);
        }
    }

    public function handle_close_job() {

        if ( ! isset($_GET['workora_close_job'], $_GET[WORKORA_NONCE_NAME]) ) return;
        if ( ! is_user_logged_in() || ! workora_jobs_user_is_company() ) return;

        $nonce = sanitize_text_field($_GET[WORKORA_NONCE_NAME]);
        if ( ! wp_verify_nonce($nonce, WORKORA_NONCE_ACTION) ) {
            wp_die(__('Security check failed.', WORKORA_JOBS_TEXTDOMAIN));
        }

        $job_id = intval($_GET['workora_close_job']);
        if ( $job_id <= 0 || get_post_type($job_id) !== 'job' ) return;

        $company_id = get_current_user_id();
        $author_id = (int) get_post_field('post_author', $job_id);

        if ( $author_id !== $company_id ) {
            wp_die(__('Not allowed.', WORKORA_JOBS_TEXTDOMAIN));
        }

        // Mark as closed + set to draft (hidden)
        update_post_meta($job_id, self::META_CLOSED_AT, time());
        wp_update_post([
            'ID' => $job_id,
            'post_status' => 'draft',
        ]);

        wp_safe_redirect( add_query_arg('job_closed', '1', wp_get_referer()) );
        exit;
    }

    public function cleanup_closed_jobs() {

        $threshold = time() - (14 * DAY_IN_SECONDS);

        $q = new WP_Query([
            'post_type' => 'job',
            'post_status' => ['draft','publish','pending','private'],
            'posts_per_page' => -1,
            'meta_query' => [
                [
                    'key' => self::META_CLOSED_AT,
                    'value' => $threshold,
                    'compare' => '<=',
                    'type' => 'NUMERIC',
                ]
            ],
            'fields' => 'ids',
        ]);

        if ( ! $q->have_posts() ) return;

        foreach ( $q->posts as $job_id ) {
            wp_delete_post($job_id, true);
        }
    }
}
