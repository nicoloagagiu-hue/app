<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_Loader {

    public function init() {

        require_once WORKORA_JOBS_PATH . 'includes/helpers.php';
        require_once WORKORA_JOBS_PATH . 'includes/class-workora-jobs-i18n.php';
        require_once WORKORA_JOBS_PATH . 'includes/class-workora-jobs-roles.php';
        require_once WORKORA_JOBS_PATH . 'includes/class-workora-jobs-cpt.php';
        require_once WORKORA_JOBS_PATH . 'includes/class-workora-jobs-assets.php';
        require_once WORKORA_JOBS_PATH . 'includes/class-workora-jobs-security.php';
        require_once WORKORA_JOBS_PATH . 'includes/class-workora-jobs-student.php';
        require_once WORKORA_JOBS_PATH . 'includes/class-workora-jobs-company.php';
        require_once WORKORA_JOBS_PATH . 'includes/class-workora-jobs-woo.php';
        require_once WORKORA_JOBS_PATH . 'includes/class-workora-jobs-shortcodes.php';
        require_once WORKORA_JOBS_PATH . 'includes/class-workora-jobs-applications.php';
        require_once WORKORA_JOBS_PATH . 'includes/class-workora-jobs-profile.php';
        require_once WORKORA_JOBS_PATH . 'includes/class-workora-jobs-job-create.php';
        require_once WORKORA_JOBS_PATH . 'includes/class-workora-jobs-home.php';
        require_once WORKORA_JOBS_PATH . 'includes/class-workora-jobs-registration.php';
        require_once WORKORA_JOBS_PATH . 'includes/class-workora-jobs-job-manage.php';

        ( new Workora_Jobs_I18n() )->init();
        ( new Workora_Jobs_Roles() )->init();
        ( new Workora_Jobs_CPT() )->init();
        ( new Workora_Jobs_Assets() )->init();
        ( new Workora_Jobs_Security() )->init();
        ( new Workora_Jobs_Student() )->init();
        ( new Workora_Jobs_Company() )->init();
        ( new Workora_Jobs_Woo() )->init();
        ( new Workora_Jobs_Shortcodes() )->init();
        ( new Workora_Jobs_Applications() )->init();
        ( new Workora_Jobs_Profile() )->init();
        ( new Workora_Jobs_Job_Create() )->init();
        ( new Workora_Jobs_Home() )->init();
        ( new Workora_Jobs_Registration() )->init();
        ( new Workora_Jobs_Job_Manage() )->init();
    }
}
