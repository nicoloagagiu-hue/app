<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_Profile {

    public function init() {
        add_shortcode('student_public_profile', [$this, 'render_public_profile']);
    }

    public function render_public_profile($atts) {

        if ( ! is_user_logged_in() || ! workora_jobs_user_is_company() ) {
            return __('Access denied.', WORKORA_JOBS_TEXTDOMAIN);
        }

        $atts = shortcode_atts(['id' => 0], $atts);
        $student_id = intval($atts['id']);
        if ( ! $student_id && isset($_GET['sid']) ) {
            $student_id = intval($_GET['sid']);
        }
        if ( $student_id <= 0 ) return __('Invalid student.', WORKORA_JOBS_TEXTDOMAIN);

        $student = get_user_by('id', $student_id);
        if ( ! $student ) return __('Student not found.', WORKORA_JOBS_TEXTDOMAIN);

        $company_id = get_current_user_id();
        $is_unlocked = Workora_Jobs_Company::company_has_unlocked($company_id, $student_id);

        $edu = get_user_meta($student_id, WORKORA_STUDENT_META_EDU, true);
        $exp = get_user_meta($student_id, WORKORA_STUDENT_META_EXP, true);
        $skills = get_user_meta($student_id, WORKORA_STUDENT_META_SKILLS, true);
        $skills = is_array($skills) ? $skills : [];

        ob_start();
        workora_jobs_get_template('public-profile', [
            'student' => $student,
            'is_unlocked' => $is_unlocked,
            'edu' => $edu,
            'exp' => $exp,
            'skills' => $skills,
            'student_id' => $student_id,
        ]);
        return ob_get_clean();
    }
}
