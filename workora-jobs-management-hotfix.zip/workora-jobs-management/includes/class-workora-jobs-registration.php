<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_Registration {

    public function init() {
        add_shortcode('workora_register', [$this, 'render_register']);
        add_action('init', [$this, 'handle_register_submit']);
    }

    public function render_register() {

        if ( is_user_logged_in() ) {
            return '<div class="p-4 bg-gray-50 rounded-xl">'.esc_html__('You are already logged in.', WORKORA_JOBS_TEXTDOMAIN).'</div>';
        }

        ob_start();
        workora_jobs_get_template('register');
        return ob_get_clean();
    }

    public function handle_register_submit() {

        if ( ! isset($_POST['workora_register_submit']) ) return;

        if ( ! isset($_POST[WORKORA_NONCE_NAME]) || ! wp_verify_nonce($_POST[WORKORA_NONCE_NAME], WORKORA_NONCE_ACTION) ) {
            wp_die(__('Security check failed.', WORKORA_JOBS_TEXTDOMAIN));
        }

        $role = sanitize_text_field($_POST['workora_role'] ?? '');
        if ( ! in_array($role, [WORKORA_ROLE_STUDENT, WORKORA_ROLE_COMPANY], true) ) {
            wp_safe_redirect( add_query_arg('reg', 'invalid_role', wp_get_referer()) );
            exit;
        }

        $email = sanitize_email($_POST['email'] ?? '');
        $pass  = (string) ($_POST['password'] ?? '');
        $company_name = sanitize_text_field($_POST['company_name'] ?? '');

        if ( empty($email) || empty($pass) ) {
            wp_safe_redirect( add_query_arg('reg', 'missing', wp_get_referer()) );
            exit;
        }

        if ( $role === WORKORA_ROLE_COMPANY && empty($company_name) ) {
            wp_safe_redirect( add_query_arg('reg', 'missing_company', wp_get_referer()) );
            exit;
        }

        if ( email_exists($email) ) {
            wp_safe_redirect( add_query_arg('reg', 'exists', wp_get_referer()) );
            exit;
        }

        $username = sanitize_user( current( explode('@', $email) ), true );
        if ( username_exists($username) ) {
            $username .= '_' . wp_generate_password(4, false, false);
        }

        $user_id = wc_create_new_customer( $email, $username, $pass );

        if ( is_wp_error($user_id) ) {
            wp_safe_redirect( add_query_arg('reg', 'fail', wp_get_referer()) );
            exit;
        }

        $user = new WP_User($user_id);
        $user->set_role($role);

        if ( $role === WORKORA_ROLE_COMPANY ) {
            update_user_meta($user_id, '_workora_company_name', $company_name);
            wp_update_user(['ID' => $user_id, 'display_name' => $company_name]);
        }

        // Auto-login
        wc_set_customer_auth_cookie($user_id);

        // Redirect
        $redirect = ($role === WORKORA_ROLE_COMPANY) ? site_url('/dashboard-azienda/') : site_url('/dashboard-studente/');
        wp_safe_redirect( add_query_arg('registered', '1', $redirect) );
        exit;
    }
}
