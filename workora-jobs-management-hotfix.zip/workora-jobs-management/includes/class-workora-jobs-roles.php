<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_Roles {

    public function init() {
        add_action('woocommerce_register_form', [$this, 'add_role_field_to_register']);
        add_filter('woocommerce_registration_errors', [$this, 'validate_role_field'], 10, 3);
        add_action('woocommerce_created_customer', [$this, 'assign_role_on_register']);
    }

    public function add_role_field_to_register() {
        if ( defined('WORKORA_DISABLE_WC_ROLE_FIELD') && WORKORA_DISABLE_WC_ROLE_FIELD ) return;
        ?>
        <p class="form-row form-row-wide">
            <label><?php _e('I am a:', WORKORA_JOBS_TEXTDOMAIN); ?> <span class="required">*</span></label>
            <select name="workora_user_role" required>
                <option value=""><?php _e('Select...', WORKORA_JOBS_TEXTDOMAIN); ?></option>
                <option value="<?php echo esc_attr(WORKORA_ROLE_STUDENT); ?>"><?php _e('Student', WORKORA_JOBS_TEXTDOMAIN); ?></option>
                <option value="<?php echo esc_attr(WORKORA_ROLE_COMPANY); ?>"><?php _e('Company', WORKORA_JOBS_TEXTDOMAIN); ?></option>
            </select>
        </p>
        <?php
    }

    public function validate_role_field($errors, $username, $email) {
        if ( empty($_POST['workora_user_role']) ) {
            $errors->add('workora_role_error', __('Please select a role.', WORKORA_JOBS_TEXTDOMAIN));
        }
        return $errors;
    }

    public function assign_role_on_register($customer_id) {
        if ( empty($_POST['workora_user_role']) ) return;

        $role = sanitize_text_field($_POST['workora_user_role']);

        if ( ! in_array($role, [WORKORA_ROLE_STUDENT, WORKORA_ROLE_COMPANY], true) ) return;

        $user = new WP_User($customer_id);
        $user->set_role($role);
    }
}
