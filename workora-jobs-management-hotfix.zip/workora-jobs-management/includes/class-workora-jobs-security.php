<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_Security {

    public function init() {
        // Placeholder per future misure
    }

    public static function user_has_role( $role ) {
        $user = wp_get_current_user();
        return in_array( $role, (array) $user->roles, true );
    }

    public static function sanitize_skills( $skills ) {
        $skills = explode( ',', $skills );
        $skills = array_map( 'sanitize_text_field', $skills );
        return array_filter( $skills );
    }
}
