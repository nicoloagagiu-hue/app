<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_Shortcodes {

    public function init() {
        add_shortcode( 'workora_registration', [ $this, 'registration_shortcode' ] );
        add_shortcode( 'student_dashboard', [ $this, 'student_dashboard_shortcode' ] );
        add_shortcode( 'company_dashboard', [ $this, 'company_dashboard_shortcode' ] );
        add_shortcode( 'company_create_job', [ $this, 'company_create_job_shortcode' ] );
    }

    public function registration_shortcode() {
        ob_start();
        workora_jobs_get_template( 'registration' );
        return ob_get_clean();
    }

    public function student_dashboard_shortcode() {
        if ( ! is_user_logged_in() || ! workora_jobs_user_is_student() ) {
            return __( 'Access denied.', WORKORA_JOBS_TEXTDOMAIN );
        }
        ob_start();
        workora_jobs_get_template( 'student-dashboard' );
        return ob_get_clean();
    }

    
    public function company_create_job_shortcode() {
        if ( ! is_user_logged_in() || ! workora_jobs_user_is_company() ) {
            return __( 'Access denied.', WORKORA_JOBS_TEXTDOMAIN );
        }
        ob_start();
        workora_jobs_get_template( 'company-create-job' );
        return ob_get_clean();
    }

    public function company_dashboard_shortcode() {
        if ( ! is_user_logged_in() || ! workora_jobs_user_is_company() ) {
            return __( 'Access denied.', WORKORA_JOBS_TEXTDOMAIN );
        }
        ob_start();
        workora_jobs_get_template( 'company-dashboard' );
        return ob_get_clean();
    }
}
