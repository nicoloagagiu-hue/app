<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_Student {

    public function init() {
        add_action( 'init', [ $this, 'handle_profile_save' ] );
    }

    public function handle_profile_save() {

        if ( ! isset($_POST['workora_student_save']) ) return;
        if ( ! workora_jobs_user_is_student() ) return;

        if ( ! isset($_POST[WORKORA_NONCE_NAME]) ||
             ! wp_verify_nonce($_POST[WORKORA_NONCE_NAME], WORKORA_NONCE_ACTION) ) {
            wp_die( __( 'Security check failed.', WORKORA_JOBS_TEXTDOMAIN ) );
        }

        $user_id = get_current_user_id();

        update_user_meta( $user_id, $dob_key, sanitize_text_field($_POST['dob'] ?? '') );
        update_user_meta( $user_id, $phone_key, sanitize_text_field($_POST['phone'] ?? '') );
        update_user_meta( $user_id, '_workora_edu', sanitize_textarea_field($_POST['education'] ?? '') );
        update_user_meta( $user_id, '_workora_exp', sanitize_textarea_field($_POST['experience'] ?? '') );

        $skills = Workora_Jobs_Security::sanitize_skills($_POST['skills'] ?? '');
        update_user_meta( $user_id, '_workora_skills', $skills );

        wp_safe_redirect( add_query_arg('saved', '1', wp_get_referer()) );
        exit;
    }
}
