<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class Workora_Jobs_Woo {

    public function init() {
        add_action( 'wp_loaded', [ $this, 'handle_unlock_request' ] );
        add_filter( 'woocommerce_add_cart_item_data', [ $this, 'add_student_meta_to_cart' ], 10, 3 );
        add_filter( 'woocommerce_get_item_data', [ $this, 'display_student_meta_cart' ], 10, 2 );
        add_action( 'woocommerce_thankyou', [ $this, 'handle_order_complete' ], 10, 1 );
    }

    /**
     * Trigger: click “Sblocca Contatto”
     */
    public function handle_unlock_request() {

        if ( ! isset($_GET['workora_unlock_student']) ) return;
        if ( ! is_user_logged_in() || ! workora_jobs_user_is_company() ) return;

        $student_id = intval($_GET['workora_unlock_student']);
        if ( $student_id <= 0 ) return;

        $company_id = get_current_user_id();

        // Anti-duplicazione: se già sbloccato, non aggiunge al carrello
        if ( Workora_Jobs_Company::company_has_unlocked($company_id, $student_id) ) {
            wp_safe_redirect( add_query_arg('unlocked', 'already', wp_get_referer()) );
            exit;
        }

        WC()->cart->add_to_cart( WORKORA_UNLOCK_PRODUCT_ID, 1, 0, [], [
            WORKORA_CART_KEY_STUDENT_ID => $student_id
        ] );

        wp_safe_redirect( wc_get_cart_url() );
        exit;
    }

    public function add_student_meta_to_cart( $cart_item_data, $product_id, $variation_id ) {

        if ( isset($_GET['workora_unlock_student']) && $product_id == WORKORA_UNLOCK_PRODUCT_ID ) {
            $cart_item_data[WORKORA_CART_KEY_STUDENT_ID] = intval($_GET['workora_unlock_student']);
        }

        return $cart_item_data;
    }

    public function display_student_meta_cart( $item_data, $cart_item ) {

        if ( isset($cart_item[WORKORA_CART_KEY_STUDENT_ID]) ) {
            $item_data[] = [
                'name' => __( 'Student ID', WORKORA_JOBS_TEXTDOMAIN ),
                'value' => intval($cart_item[WORKORA_CART_KEY_STUDENT_ID]),
            ];
        }
        return $item_data;
    }

    public function handle_order_complete( $order_id ) {

        if ( ! $order_id ) return;

        $order = wc_get_order( $order_id );
        if ( ! $order ) return;

        $status = $order->get_status();
        if ( in_array($status, ['failed','cancelled','refunded'], true) ) {
            return;
        }

        $company_id = $order->get_user_id();
        if ( ! $company_id ) return;

        $unlocked = Workora_Jobs_Company::get_unlocked_students( $company_id );

        foreach ( $order->get_items() as $item ) {
            $student_id = $item->get_meta( WORKORA_CART_KEY_STUDENT_ID, true );
            if ( $student_id ) {
                $student_id = intval($student_id);
                if ( ! in_array($student_id, $unlocked, true) ) {
                    $unlocked[] = $student_id;
                }
            }
        }

        update_user_meta( $company_id, WORKORA_META_UNLOCKED_STUDENTS, $unlocked );
    }
}
