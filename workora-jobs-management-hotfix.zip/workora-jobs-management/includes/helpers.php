<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function workora_jobs_get_template( $template, $vars = [] ) {
    $path = WORKORA_JOBS_PATH . "templates/{$template}.php";
    if ( file_exists( $path ) ) {
        extract( $vars );
        include $path;
    }
}

function workora_jobs_user_is_student() {
    return Workora_Jobs_Security::user_has_role( WORKORA_ROLE_STUDENT );
}

function workora_jobs_user_is_company() {
    return Workora_Jobs_Security::user_has_role( WORKORA_ROLE_COMPANY );
}
