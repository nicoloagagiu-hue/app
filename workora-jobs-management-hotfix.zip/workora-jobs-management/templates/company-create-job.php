<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>

<div class="max-w-3xl mx-auto bg-white p-6 rounded-2xl shadow">
    <h1 class="text-2xl font-bold mb-6"><?php _e('Create New Job / Project', WORKORA_JOBS_TEXTDOMAIN); ?></h1>

    <?php if ( isset($_GET['job_created']) && $_GET['job_created'] === 'success' ): ?>
        <div class="p-3 mb-4 bg-green-100 text-green-800 rounded-lg">
            <?php _e('Job created successfully!', WORKORA_JOBS_TEXTDOMAIN); ?>
        </div>
    <?php endif; ?>

    <?php if ( isset($_GET['job_created']) && $_GET['job_created'] === 'fail' ): ?>
        <div class="p-3 mb-4 bg-red-100 text-red-800 rounded-lg">
            <?php _e('Please fill in all fields.', WORKORA_JOBS_TEXTDOMAIN); ?>
        </div>
    <?php endif; ?>

    <form method="post" class="space-y-4">

        <?php wp_nonce_field( WORKORA_NONCE_ACTION, WORKORA_NONCE_NAME ); ?>

        <div>
            <label class="block text-sm font-semibold"><?php _e('Job Title', WORKORA_JOBS_TEXTDOMAIN); ?></label>
            <input type="text" name="job_title" required
                   class="w-full border rounded-lg p-2"/>
        </div>

        <div>
            <label class="block text-sm font-semibold"><?php _e('Job Description', WORKORA_JOBS_TEXTDOMAIN); ?></label>
            <textarea name="job_description" required
                      class="w-full border rounded-lg p-2" rows="6"></textarea>
        </div>

        <button name="workora_create_job_submit" value="1"
                class="bg-black text-white py-2 px-4 rounded-lg w-full">
            <?php _e('Publish Job', WORKORA_JOBS_TEXTDOMAIN); ?>
        </button>

    </form>
</div>
