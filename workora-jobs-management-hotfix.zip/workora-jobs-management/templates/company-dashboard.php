<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$company_id = get_current_user_id();

// Jobs created by this company
$jobs = get_posts([
    'post_type' => 'job',
    'post_status' => 'publish',
    'author' => $company_id,
    'numberposts' => -1,
]);

// Students list for paywall grid (optional section)
$students = get_users([ 'role' => WORKORA_ROLE_STUDENT ]);

?>
<div class="max-w-6xl mx-auto bg-white p-6 rounded-2xl shadow">
    <h1 class="text-2xl font-bold mb-4"><?php _e('Company Dashboard', WORKORA_JOBS_TEXTDOMAIN); ?></h1>

    <div class="flex flex-col md:flex-row md:items-center md:justify-between gap-3 mb-6">
        <div class="text-sm text-gray-600">
            <?php _e('Manage your job offers and review applications.', WORKORA_JOBS_TEXTDOMAIN); ?>
        </div>
        <a href="<?php echo esc_url( site_url('/crea-offerta/') ); ?>"
           class="inline-block bg-black text-white px-5 py-3 rounded-lg">
            <?php _e('Create New Job / Project', WORKORA_JOBS_TEXTDOMAIN); ?>
        </a>
    </div>

    <?php if ( isset($_GET['unlocked']) && $_GET['unlocked'] === 'already' ): ?>
        <div class="p-3 mb-4 bg-yellow-100 text-yellow-800 rounded-lg">
            <?php _e('You have already unlocked this contact.', WORKORA_JOBS_TEXTDOMAIN); ?>
        </div>
    <?php endif; ?>

    <?php if ( isset($_GET['job_closed']) ): ?>
        <div class="p-3 mb-4 bg-green-100 text-green-800 rounded-lg">
            <?php _e('Job closed successfully. It will be deleted automatically in 14 days.', WORKORA_JOBS_TEXTDOMAIN); ?>
        </div>
    <?php endif; ?>

    <?php if ( isset($_GET['registered']) ): ?>
        <div class="p-3 mb-4 bg-green-100 text-green-800 rounded-lg">
            <?php _e('Welcome! Your company account is ready.', WORKORA_JOBS_TEXTDOMAIN); ?>
        </div>
    <?php endif; ?>

    <!-- JOBS LIST -->
    <div class="mb-10">
        <h2 class="text-xl font-bold mb-4"><?php _e('Your Job Offers', WORKORA_JOBS_TEXTDOMAIN); ?></h2>

        <?php if ( empty($jobs) ): ?>
            <div class="p-4 bg-gray-50 rounded-xl text-gray-700">
                <?php _e('You have not published any job offers yet.', WORKORA_JOBS_TEXTDOMAIN); ?>
            </div>
        <?php else: ?>

            <div class="space-y-6">
                <?php foreach ( $jobs as $job ): ?>
                    <?php
                    $job_id = $job->ID;

                    // Applications for this job
                    $apps = get_posts([
                        'post_type' => 'application',
                        'post_status' => 'publish',
                        'numberposts' => -1,
                        'meta_key' => '_workora_job_id',
                        'meta_value' => $job_id,
                    ]);
                    ?>
                    <div class="border rounded-2xl p-5">
                        <div class="flex flex-col md:flex-row md:items-start md:justify-between gap-3">
                            <div>
                                <h3 class="text-lg font-bold"><?php echo esc_html( get_the_title($job_id) ); ?></h3>
                                <a href="<?php echo esc_url( get_permalink($job_id) ); ?>" class="text-sm underline text-gray-700">
                                    <?php _e('View job page', WORKORA_JOBS_TEXTDOMAIN); ?>
                                </a>
                            </div>
                            <div class="flex flex-col items-start md:items-end gap-2">
                                <div class="text-sm text-gray-600">
                                    <?php printf( esc_html__('%d applications', WORKORA_JOBS_TEXTDOMAIN), count($apps) ); ?>
                                </div>
                                <?php
                                    $close_url = add_query_arg([
                                        'workora_close_job' => $job_id,
                                        WORKORA_NONCE_NAME => wp_create_nonce(WORKORA_NONCE_ACTION),
                                    ]);
                                ?>
                                <a href="<?php echo esc_url($close_url); ?>" class="text-sm bg-red-600 text-white px-3 py-2 rounded-lg" onclick="return confirm('<?php echo esc_js(__('Close this job offer? It will be deleted in 14 days.', WORKORA_JOBS_TEXTDOMAIN)); ?>');">
                                    <?php _e('Close offer', WORKORA_JOBS_TEXTDOMAIN); ?>
                                </a>
                            </div>
                        </div>

                        <div class="mt-4">
                            <h4 class="font-semibold mb-2"><?php _e('Applicants', WORKORA_JOBS_TEXTDOMAIN); ?></h4>

                            <?php if ( empty($apps) ): ?>
                                <div class="p-3 bg-gray-50 rounded-lg text-sm text-gray-700">
                                    <?php _e('No applications yet.', WORKORA_JOBS_TEXTDOMAIN); ?>
                                </div>
                            <?php else: ?>
                                <div class="divide-y border rounded-xl overflow-hidden">
                                    <?php foreach ( $apps as $app ): ?>
                                        <?php
                                        $student_id = (int) get_post_meta($app->ID, '_workora_student_id', true);
                                        $student = get_user_by('id', $student_id);
                                        if ( ! $student ) continue;

                                        $edu = get_user_meta($student_id, WORKORA_STUDENT_META_EDU, true);
                                        $skills = get_user_meta($student_id, WORKORA_STUDENT_META_SKILLS, true);
                                        $skills = is_array($skills) ? $skills : [];

                                        // Public profile link (contacts locked unless unlocked)
                                        // Use a dedicated page with shortcode [student_public_profile id="..."]
                                        $profile_page = site_url('/profilo-candidato/');
                                        $profile_url = add_query_arg('sid', $student_id, $profile_page);
                                        ?>
                                        <div class="p-4 flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                                            <div>
                                                <div class="font-semibold"><?php echo esc_html($student->display_name); ?></div>
                                                <div class="text-sm text-gray-600 mt-1">
                                                    <span class="font-medium"><?php _e('Education:', WORKORA_JOBS_TEXTDOMAIN); ?></span>
                                                    <?php echo esc_html($edu); ?>
                                                </div>
                                                <?php if ( ! empty($skills) ): ?>
                                                    <div class="text-sm text-gray-600 mt-1">
                                                        <span class="font-medium"><?php _e('Skills:', WORKORA_JOBS_TEXTDOMAIN); ?></span>
                                                        <?php echo esc_html( implode(', ', $skills) ); ?>
                                                    </div>
                                                <?php endif; ?>
                                            </div>

                                            <a href="<?php echo esc_url($profile_url); ?>"
                                               class="inline-block bg-black text-white px-4 py-2 rounded-lg text-sm">
                                                <?php _e('Discover more', WORKORA_JOBS_TEXTDOMAIN); ?> →
                                            </a>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>

        <?php endif; ?>
    </div>

    <!-- OPTIONAL: CANDIDATES PAYWALL GRID -->
    <div>
        <h2 class="text-xl font-bold mb-4"><?php _e('All Candidates', WORKORA_JOBS_TEXTDOMAIN); ?></h2>
        <div class="grid md:grid-cols-3 gap-4">
            <?php foreach( $students as $student ): ?>

                <?php
                $student_id = $student->ID;

                $edu = get_user_meta($student_id, WORKORA_STUDENT_META_EDU, true);
                $skills = get_user_meta($student_id, WORKORA_STUDENT_META_SKILLS, true);
                $skills = is_array($skills) ? $skills : [];

                $is_unlocked = Workora_Jobs_Company::company_has_unlocked($company_id, $student_id);
                ?>

                <div class="border rounded-xl p-4">
                    <h2 class="font-bold text-lg"><?php echo esc_html($student->display_name); ?></h2>

                    <p class="text-sm mt-2">
                        <strong><?php _e('Education:', WORKORA_JOBS_TEXTDOMAIN); ?></strong>
                        <?php echo esc_html($edu); ?>
                    </p>

                    <p class="text-sm mt-2">
                        <strong><?php _e('Skills:', WORKORA_JOBS_TEXTDOMAIN); ?></strong>
                        <?php echo esc_html( implode(', ', $skills) ); ?>
                    </p>

                    <?php if ( $is_unlocked ): ?>
                        <div class="mt-4 bg-green-50 p-3 rounded-lg text-sm">
                            <p><strong><?php _e('Email:', WORKORA_JOBS_TEXTDOMAIN); ?></strong> </p>
                            <p><strong><?php _e('Phone:', WORKORA_JOBS_TEXTDOMAIN); ?></strong> <?php echo esc_html(get_user_meta($student_id, WORKORA_STUDENT_META_PHONE, true)); ?></p>
                        </div>
                    <?php else: ?>
                        <div class="mt-4 bg-gray-50 p-3 rounded-lg text-sm">
                            <p class="mb-2"><?php _e('Contact details are locked.', WORKORA_JOBS_TEXTDOMAIN); ?></p>

                            <a href="<?php echo esc_url( add_query_arg('workora_unlock_student', $student_id) ); ?>"
                               class="block w-full text-center bg-black text-white py-2 rounded-lg">
                                <?php _e('Unlock Contact (5€)', WORKORA_JOBS_TEXTDOMAIN); ?>
                            </a>
                        </div>
                    <?php endif; ?>

                </div>

            <?php endforeach; ?>
        </div>
    </div>
</div>
