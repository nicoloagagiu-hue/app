<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$profile_image_id = (int) get_user_meta($student_id, '_workora_profile_image_id', true);
$profile_image_url = $profile_image_id ? wp_get_attachment_url($profile_image_id) : '';

$first_name = get_user_meta($student_id, '_workora_first_name', true);
$last_name  = get_user_meta($student_id, '_workora_last_name', true);
$display = trim($first_name . ' ' . $last_name);
$display = $display ? $display : $student->display_name;

$dob = get_user_meta($student_id, '_workora_dob', true);

$edu = get_user_meta($student_id, '_workora_edu', true);
$exp = get_user_meta($student_id, '_workora_exp', true);

$skills = get_user_meta($student_id, '_workora_skills', true);
$skills = is_array($skills) ? $skills : array_filter(array_map('trim', explode(',', (string)$skills)));
?>
<div class="max-w-3xl mx-auto bg-white p-6 rounded-2xl shadow">
    <div class="flex items-center gap-4">
        <?php if ( $profile_image_url ): ?>
            <img src="<?php echo esc_url($profile_image_url); ?>" class="w-16 h-16 rounded-full object-cover border" alt="<?php echo esc_attr($display); ?>">
        <?php endif; ?>
        <div>
            <h1 class="text-2xl font-bold"><?php echo esc_html($display); ?></h1>
            <?php if ( $dob ): ?>
                <p class="text-sm text-gray-600 mt-1"><?php _e('Data di nascita:', WORKORA_JOBS_TEXTDOMAIN); ?> <?php echo esc_html($dob); ?></p>
            <?php endif; ?>
        </div>
    </div>

    <div class="mt-6">
        <h2 class="font-semibold"><?php _e('Istruzione', WORKORA_JOBS_TEXTDOMAIN); ?></h2>
        <p class="text-sm whitespace-pre-line"><?php echo esc_html($edu); ?></p>
    </div>

    <div class="mt-4">
        <h2 class="font-semibold"><?php _e('Esperienze', WORKORA_JOBS_TEXTDOMAIN); ?></h2>
        <p class="text-sm whitespace-pre-line"><?php echo esc_html($exp); ?></p>
    </div>

    <div class="mt-4">
        <h2 class="font-semibold"><?php _e('Competenze', WORKORA_JOBS_TEXTDOMAIN); ?></h2>
        <div class="flex flex-wrap gap-2 mt-2">
            <?php foreach($skills as $s): ?>
                <span class="px-3 py-1 text-xs bg-gray-100 rounded-full"><?php echo esc_html($s); ?></span>
            <?php endforeach; ?>
        </div>
    </div>

    <div class="mt-6 border-t pt-4">
        <?php if ($is_unlocked): ?>
            <div class="bg-green-50 p-4 rounded-lg text-sm">
                <p><strong><?php _e('Email:', WORKORA_JOBS_TEXTDOMAIN); ?></strong> <?php echo esc_html($student->user_email); ?></p>
                <p><strong><?php _e('Telefono:', WORKORA_JOBS_TEXTDOMAIN); ?></strong> <?php echo esc_html(get_user_meta($student_id, '_workora_phone', true)); ?></p>
            </div>
        <?php else: ?>
            <div class="bg-gray-50 p-4 rounded-lg text-sm">
                <p class="mb-2"><?php _e('I dati di contatto sono bloccati.', WORKORA_JOBS_TEXTDOMAIN); ?></p>
                <a href="<?php echo esc_url( add_query_arg('workora_unlock_student', $student_id, wc_get_cart_url()) ); ?>"
                   class="inline-block bg-black text-white px-4 py-2 rounded-lg">
                    <?php _e('Sblocca Contatto (5€)', WORKORA_JOBS_TEXTDOMAIN); ?>
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>
