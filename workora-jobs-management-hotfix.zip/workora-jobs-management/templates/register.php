<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>

<div class="max-w-5xl mx-auto bg-white p-6 rounded-2xl shadow">
    <h1 class="text-3xl font-bold mb-2"><?php _e('Create your account', WORKORA_JOBS_TEXTDOMAIN); ?></h1>
    <p class="text-gray-600 mb-6"><?php _e('Choose if you are a student or a company. Registration is immediate.', WORKORA_JOBS_TEXTDOMAIN); ?></p>

    <?php
    $reg = $_GET['reg'] ?? '';
    $messages = [
        'missing' => __('Please fill in email and password.', WORKORA_JOBS_TEXTDOMAIN),
        'missing_company' => __('Please enter your company name.', WORKORA_JOBS_TEXTDOMAIN),
        'exists' => __('An account with this email already exists.', WORKORA_JOBS_TEXTDOMAIN),
        'invalid_role' => __('Invalid role selection.', WORKORA_JOBS_TEXTDOMAIN),
        'fail' => __('Registration failed. Please try again.', WORKORA_JOBS_TEXTDOMAIN),
    ];
    if ( $reg && isset($messages[$reg]) ): ?>
        <div class="p-3 mb-4 bg-red-100 text-red-800 rounded-lg"><?php echo esc_html($messages[$reg]); ?></div>
    <?php endif; ?>

    <div class="grid md:grid-cols-2 gap-6">
        <!-- Student -->
        <div class="border rounded-2xl p-6">
            <h2 class="text-xl font-bold mb-4"><?php _e('Student', WORKORA_JOBS_TEXTDOMAIN); ?></h2>
            <form method="post" class="space-y-3">
                <?php wp_nonce_field( WORKORA_NONCE_ACTION, WORKORA_NONCE_NAME ); ?>
                <input type="hidden" name="workora_role" value="<?php echo esc_attr(WORKORA_ROLE_STUDENT); ?>">
                <div>
                    <label class="block text-sm font-semibold"><?php _e('Email', WORKORA_JOBS_TEXTDOMAIN); ?></label>
                    <input type="email" name="email" required class="w-full border rounded-lg p-2"/>
                </div>
                <div>
                    <label class="block text-sm font-semibold"><?php _e('Password', WORKORA_JOBS_TEXTDOMAIN); ?></label>
                    <input type="password" name="password" required class="w-full border rounded-lg p-2"/>
                </div>
                <button name="workora_register_submit" value="1" class="w-full bg-black text-white py-2 rounded-lg">
                    <?php _e('Register as Student', WORKORA_JOBS_TEXTDOMAIN); ?>
                </button>
            </form>
        </div>

        <!-- Company -->
        <div class="border rounded-2xl p-6">
            <h2 class="text-xl font-bold mb-4"><?php _e('Company', WORKORA_JOBS_TEXTDOMAIN); ?></h2>
            <form method="post" class="space-y-3">
                <?php wp_nonce_field( WORKORA_NONCE_ACTION, WORKORA_NONCE_NAME ); ?>
                <input type="hidden" name="workora_role" value="<?php echo esc_attr(WORKORA_ROLE_COMPANY); ?>">
                <div>
                    <label class="block text-sm font-semibold"><?php _e('Company name', WORKORA_JOBS_TEXTDOMAIN); ?></label>
                    <input type="text" name="company_name" required class="w-full border rounded-lg p-2"/>
                </div>
                <div>
                    <label class="block text-sm font-semibold"><?php _e('Email', WORKORA_JOBS_TEXTDOMAIN); ?></label>
                    <input type="email" name="email" required class="w-full border rounded-lg p-2"/>
                </div>
                <div>
                    <label class="block text-sm font-semibold"><?php _e('Password', WORKORA_JOBS_TEXTDOMAIN); ?></label>
                    <input type="password" name="password" required class="w-full border rounded-lg p-2"/>
                </div>
                <button name="workora_register_submit" value="1" class="w-full bg-black text-white py-2 rounded-lg">
                    <?php _e('Register as Company', WORKORA_JOBS_TEXTDOMAIN); ?>
                </button>
            </form>
        </div>
    </div>

    <div class="mt-6 text-sm text-gray-600">
        <?php _e('Already have an account?', WORKORA_JOBS_TEXTDOMAIN); ?>
        <a class="underline" href="<?php echo esc_url( wc_get_page_permalink('myaccount') ); ?>">
            <?php _e('Login here', WORKORA_JOBS_TEXTDOMAIN); ?>
        </a>
    </div>
</div>
