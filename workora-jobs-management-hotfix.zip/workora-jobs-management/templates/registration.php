<?php
if ( ! defined( 'ABSPATH' ) ) exit;
?>
<div class="p-6 bg-white rounded-2xl shadow">
    <h2 class="text-xl font-bold mb-3"><?php _e('Registration', WORKORA_JOBS_TEXTDOMAIN); ?></h2>
    <p class="text-sm text-gray-600"><?php _e('Use the WooCommerce registration form. You will be asked to choose your role.', WORKORA_JOBS_TEXTDOMAIN); ?></p>
</div>
