<?php
if ( ! defined( 'ABSPATH' ) ) exit;

$user_id = get_current_user_id();

$first_name = get_user_meta($user_id, '_workora_first_name', true);
$last_name  = get_user_meta($user_id, '_workora_last_name', true);
$dob = get_user_meta($user_id, '_workora_dob', true);
$phone = get_user_meta($user_id, '_workora_phone', true);
$profile_image_id = (int) get_user_meta($user_id, '_workora_profile_image_id', true);
$profile_image_url = $profile_image_id ? wp_get_attachment_url($profile_image_id) : '';

$edu = get_user_meta($user_id, '_workora_edu', true);
$exp = get_user_meta($user_id, '_workora_exp', true);

$skills = get_user_meta($user_id, '_workora_skills', true);
$skills = is_array($skills) ? implode(',', $skills) : (string) $skills;

$email = wp_get_current_user()->user_email;
?>

<div class="max-w-4xl mx-auto bg-white p-6 rounded-2xl shadow">

    <h1 class="text-2xl font-bold mb-6"><?php _e('Dashboard Studente', WORKORA_JOBS_TEXTDOMAIN); ?></h1>

    <?php if ( isset($_GET['registered']) ): ?>
        <div class="p-3 mb-4 bg-green-100 text-green-800 rounded-lg">
            <?php _e('Benvenuto! Completa il tuo CV per aumentare le possibilità.', WORKORA_JOBS_TEXTDOMAIN); ?>
        </div>
    <?php endif; ?>

    <?php if ( isset($_GET['saved']) ): ?>
        <div class="p-3 mb-4 bg-green-100 text-green-800 rounded-lg">
            <?php _e('Profilo salvato con successo!', WORKORA_JOBS_TEXTDOMAIN); ?>
        </div>
    <?php endif; ?>

    <form method="post" class="space-y-6">

        <?php wp_nonce_field( WORKORA_NONCE_ACTION, WORKORA_NONCE_NAME ); ?>

        <!-- Foto profilo -->
        <div class="border rounded-2xl p-4">
            <h2 class="text-lg font-bold mb-3"><?php _e('Foto profilo', WORKORA_JOBS_TEXTDOMAIN); ?></h2>
            <div class="flex items-center gap-4">
                <img id="workora_profile_preview"
                     src="<?php echo esc_url($profile_image_url); ?>"
                     class="w-20 h-20 rounded-full object-cover border <?php echo $profile_image_url ? '' : 'hidden'; ?>" />
                <div>
                    <input type="hidden" id="workora_profile_image_id" name="profile_image_id" value="<?php echo esc_attr($profile_image_id); ?>">
                    <button id="workora_upload_btn" class="bg-black text-white px-4 py-2 rounded-lg" type="button">
                        <?php _e('Carica / Seleziona immagine', WORKORA_JOBS_TEXTDOMAIN); ?>
                    </button>
                    <p class="text-sm text-gray-600 mt-2"><?php _e('Consigliato: immagine quadrata, minimo 400x400.', WORKORA_JOBS_TEXTDOMAIN); ?></p>
                </div>
            </div>
        </div>

        <!-- Dati personali -->
        <div class="border rounded-2xl p-4">
            <h2 class="text-lg font-bold mb-3"><?php _e('Dati personali', WORKORA_JOBS_TEXTDOMAIN); ?></h2>

            <div class="grid md:grid-cols-2 gap-4">
                <div>
                    <label class="block text-sm font-semibold"><?php _e('Nome', WORKORA_JOBS_TEXTDOMAIN); ?></label>
                    <input type="text" name="first_name" value="<?php echo esc_attr($first_name); ?>"
                           class="w-full border rounded-lg p-2" required/>
                </div>

                <div>
                    <label class="block text-sm font-semibold"><?php _e('Cognome', WORKORA_JOBS_TEXTDOMAIN); ?></label>
                    <input type="text" name="last_name" value="<?php echo esc_attr($last_name); ?>"
                           class="w-full border rounded-lg p-2" required/>
                </div>

                <div>
                    <label class="block text-sm font-semibold"><?php _e('Data di nascita', WORKORA_JOBS_TEXTDOMAIN); ?></label>
                    <input type="date" name="dob" value="<?php echo esc_attr($dob); ?>"
                           class="w-full border rounded-lg p-2"/>
                </div>

                <div>
                    <label class="block text-sm font-semibold"><?php _e('Email', WORKORA_JOBS_TEXTDOMAIN); ?></label>
                    <input type="email" name="email" value="<?php echo esc_attr($email); ?>"
                           class="w-full border rounded-lg p-2" required/>
                    <p class="text-xs text-gray-500 mt-1"><?php _e('L’email sarà visibile alle aziende solo dopo sblocco contatto.', WORKORA_JOBS_TEXTDOMAIN); ?></p>
                </div>

                <div>
                    <label class="block text-sm font-semibold"><?php _e('Telefono (privato)', WORKORA_JOBS_TEXTDOMAIN); ?></label>
                    <input type="text" name="phone" value="<?php echo esc_attr($phone); ?>"
                           class="w-full border rounded-lg p-2"/>
                    <p class="text-xs text-gray-500 mt-1"><?php _e('Il numero sarà visibile alle aziende solo dopo sblocco contatto.', WORKORA_JOBS_TEXTDOMAIN); ?></p>
                </div>
            </div>
        </div>

        <!-- Profilo Educational -->
        <div class="border rounded-2xl p-4">
            <h2 class="text-lg font-bold mb-3"><?php _e('Profilo Educational', WORKORA_JOBS_TEXTDOMAIN); ?></h2>
            <textarea name="education" class="w-full border rounded-lg p-2" rows="5"
                      placeholder="<?php esc_attr_e('Inserisci formazione, università, corsi, certificazioni...', WORKORA_JOBS_TEXTDOMAIN); ?>"><?php echo esc_textarea($edu); ?></textarea>
        </div>

        <!-- Esperienze Lavorative -->
        <div class="border rounded-2xl p-4">
            <h2 class="text-lg font-bold mb-3"><?php _e('Esperienze lavorative', WORKORA_JOBS_TEXTDOMAIN); ?></h2>
            <textarea name="experience" class="w-full border rounded-lg p-2" rows="6"
                      placeholder="<?php esc_attr_e('Inserisci le tue esperienze lavorative, progetti e risultati...', WORKORA_JOBS_TEXTDOMAIN); ?>"><?php echo esc_textarea($exp); ?></textarea>
        </div>

        <!-- Skills -->
        <div class="border rounded-2xl p-4">
            <h2 class="text-lg font-bold mb-3"><?php _e('Soft & Hard Skills', WORKORA_JOBS_TEXTDOMAIN); ?></h2>
            <label class="block text-sm font-semibold mb-1"><?php _e('Competenze (separate da virgola)', WORKORA_JOBS_TEXTDOMAIN); ?></label>
            <input type="text" name="skills" value="<?php echo esc_attr($skills); ?>"
                   class="w-full border rounded-lg p-2"
                   placeholder="<?php esc_attr_e('Esempio: Teamwork, Problem solving, Excel, Photoshop, JavaScript...', WORKORA_JOBS_TEXTDOMAIN); ?>"/>
            <p class="text-xs text-gray-500 mt-2"><?php _e('Inserisci sia soft skills che hard skills. Verranno mostrate come tag.', WORKORA_JOBS_TEXTDOMAIN); ?></p>
        </div>

        <button name="workora_student_save" value="1"
                class="bg-black text-white py-3 px-4 rounded-lg w-full text-lg">
            <?php _e('Salva CV', WORKORA_JOBS_TEXTDOMAIN); ?>
        </button>

    </form>
</div>
